"use strict";
cc._RF.push(module, '4c920T/uWlDx7QjmfnVjClP', 'config');
// Script/basic/config.js

"use strict";

// yyw config
window.config = {
    env: "develop", //develop | test | product
    server: 1
};

window.baseReqUrl = {
    "develop": "//localhost:8081/",
    "test": "//139.199.68.32:8003/",
    "product": "//animal.imifun.com/"
};

window.cdnstatic = {
    "develop": "//cdnstatic.happyia.com/www/ivp/",
    "test": "//static.mobimtech.com/ivp/",
    "product": "//cdnstatic.imifun.com/ivp/"
};

window.wxConfig = {
    fromType: "wx",
    env: "product"
};
window.loginReqUrl = {
    'develop': 'https://mini.imifun.com/',
    'test': 'https://minitest.imifun.com/',
    'product': 'https://mini.imifun.com/'
};

window.webSocketUrl = {
    "develop": "ws://10.10.9.68:8080/websocket/",
    "test": "ws://139.199.68.32:8003/websocket/",
    "product": {
        "http": "ws://animal.imifun.com/websocket/",
        "https": "wss://animal.imifun.com/websocket/"
    }

    // module.exports = {
    //     Config: config,
    //     baseReqUrl: baseReqUrl,
    //     cdnstatic: cdnstatic,
    //     webSocketUrl: webSocketUrl
    // };

};

cc._RF.pop();