"use strict";
cc._RF.push(module, 'f74d6ADM/NJG5CnvdqgWZui', 'trade');
// Script/trade.js

"use strict";

cc.Class({
    extends: cc.Component,

    properties: {},
    onLoad: function onLoad() {
        var that = this;
        that.node.getChildByName("btn2").on("touchend", function () {
            mouseStatus = true;
            that.node.active = false;
        }, that);
    },
    start: function start() {}
}

// update (dt) {},
);

cc._RF.pop();