"use strict";
cc._RF.push(module, 'a7118az5pZKx6ddCfTRFD5r', 'panel');
// Script/panel.js

"use strict";

cc.Class({
    extends: cc.Component,

    properties: {},

    onLoad: function onLoad() {
        this.node.getChildByName("bg").on("touchend", function (e) {
            e.stopPropagation();
        }, this);

        this.btnLeft = this.node.getChildByName("pop_btn_bg1");
        this.btnRight = this.node.getChildByName("pop_btn_bg2");

        // this.showPanel();
    },
    showPanel: function showPanel(objList) {
        this.node.active = true;
        var arr = {
            content: "游戏错误",
            leftBtnText: "取消",
            leftCallback: function leftCallback() {},
            rightBtnText: "确定",
            rightCallback: function rightCallback() {}
        };
        this.brr = {};
        for (var attr in arr) {
            this.brr[attr] = arr[attr];
        }
        for (var attr in objList) {
            this.brr[attr] = objList[attr];
        }

        // this.brr = $.extend(arr, objList);

        this.btnLeft.getChildByName("text").getComponent(cc.Label).string = this.brr.leftBtnText;
        this.btnRight.getChildByName("text").getComponent(cc.Label).string = this.brr.rightBtnText;
        this.node.getChildByName("text").getComponent(cc.Label).string = this.brr.content;

        this.btnLeft.once("touchend", function () {
            this.brr.leftCallback();
            this.panelBtnOff();
            this.node.active = false;
        }, this);
        this.btnRight.once("touchend", function () {
            this.brr.rightCallback();
            this.panelBtnOff();
            this.node.active = false;
        }, this);
    },
    panelBtnOff: function panelBtnOff() {
        this.btnLeft.off("touchend");
        this.btnRight.off("touchend");
    },
    start: function start() {}
}

// update (dt) {},
);

cc._RF.pop();