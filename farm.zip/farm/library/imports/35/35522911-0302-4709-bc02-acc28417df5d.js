"use strict";
cc._RF.push(module, '35522kRAwJHCbwCrMKEF99d', 'exchange');
// Script/exchange.js

"use strict";

cc.Class({
    extends: cc.Component,

    properties: {},
    onLoad: function onLoad() {
        var that = this;
        that.node.getChildByName("btn2").on("touchend", function () {
            mouseStatus = true;
            that.node.active = false;
        }, that);
    },
    start: function start() {}
}

// update (dt) {},
);

cc._RF.pop();