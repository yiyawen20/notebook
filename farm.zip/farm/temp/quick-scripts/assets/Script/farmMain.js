(function() {"use strict";var __module = CC_EDITOR ? module : {exports:{}};var __filename = 'preview-scripts/assets/Script/farmMain.js';var __require = CC_EDITOR ? function (request) {return cc.require(request, require);} : function (request) {return cc.require(request, __filename);};function __define (exports, require, module) {"use strict";
cc._RF.push(module, '9191dTMu2NAQYThmVipMklX', 'farmMain', __filename);
// Script/farmMain.js

"use strict";

var _typeof = typeof Symbol === "function" && typeof Symbol.iterator === "symbol" ? function (obj) { return typeof obj; } : function (obj) { return obj && typeof Symbol === "function" && obj.constructor === Symbol && obj !== Symbol.prototype ? "symbol" : typeof obj; };

var pool = require("pool");
var appRequest = require("network");
cc.Class({
    extends: cc.Component,

    properties: {
        tempTian: {
            default: null,
            type: cc.Prefab
        },
        buyPanel: {
            default: null,
            type: cc.Prefab
        },
        integalPanel: {
            default: null,
            type: cc.Prefab
        },
        commonPanel: {
            default: null,
            type: cc.Prefab
        },
        PermanentNode: {
            default: null,
            type: cc.Prefab
        }
    },
    onLoad: function onLoad() {
        var that = this;
        clientEvent.init();

        pool.createPrefabPool(that.tempTian);
        that.tPosList = [];
        that.rows = 4;
        that.columns = 3;

        var tianArr = [[[218, 136], [216, 136], [218, 136]], [[226, 146], [226, 146], [226, 146]], [[236, 160], [236, 160], [236, 160]], [[248, 174], [248, 174], [248, 174]]];

        //初始化格子坐标
        for (var x = 0; x < that.rows; x++) {
            var areaLine = [];
            var longY = 0;
            for (var z = 0; z < x; z++) {
                longY += tianArr[z][0][1];
            }
            // longY += 5*x;
            for (var y = 0; y < that.columns; y++) {
                // let _pos = tianArr[x][y];
                var longX = tianArr[x][y][0];
                var _x = x - 1 < 0 ? 0 : x - 1;
                // let longY = tianArr[_x][y][1];
                var pos = cc.v2((longX - 15) * ((y - 1) % 2), -longY);
                areaLine[y] = pos;
            }
            that.tPosList.push(areaLine);
        }
        cc.log('田的坐标：', JSON.stringify(that.tPosList));

        that.getMap();

        var exchange = that.node.getChildByName("exchange");
        that.node.getChildByName("icon–dhzx").on("touchend", function () {
            if (!mouseStatus) return;
            mouseStatus = false;
            exchange.active = true;
        }, that);

        var trade = that.node.getChildByName("trade");
        that.node.getChildByName("icon_jysc").on("touchend", function () {
            if (!mouseStatus) return;
            mouseStatus = false;
            trade.active = true;
        }, that);

        return;

        //积分说明
        var integalPanel = cc.instantiate(that.integalPanel);
        integalPanel.active = false;
        that.node.addChild(integalPanel);
        that.node.getChildByName("page1_integral_about").on("touchend", function (evt) {
            integalPanel.active = true;
        }, that);

        //panel
        var commonPanel = cc.instantiate(that.commonPanel);
        commonPanel.active = false;
        that.node.addChild(commonPanel);
        that.showPanel = commonPanel.getComponent("panel");
        // commonPanel.getComponent("panel").panel = that;

        // 常驻节点
        // cc.game.addPersistRootNode(that.node);

        clientEvent.on("gameUpgrade", that.gameUpgradeEvent, that);

        cc.systemEvent.on(cc.SystemEvent.EventType.KEY_DOWN, that.onKeyDown, that);
        cc.systemEvent.on(cc.SystemEvent.EventType.KEY_UP, that.onKeyUp, that);

        var PermanentNode = cc.instantiate(that.PermanentNode);
        PermanentNode.active = true;
        that.node.addChild(PermanentNode);
        that.consoleNode = PermanentNode.getComponent("console");

        that.node.on("touchstart", that.onTouchStart, that);
        that.node.on("touchend", that.onTouchEnd, that);
        that.holdClick = false;
        that.holdTimeEclipse = 0;
    },
    getMap: function getMap() {
        var that = this;
        appRequest.Get("tian", {
            token: 1,
            userId: 1
        }, function (rs) {
            var res = JSON.parse(rs);

            var _loop = function _loop(j) {
                var _loop2 = function _loop2(k) {
                    var tianNode = pool.getPrefab(that.tempTian.name);
                    var seedlings = tianNode.getChildByName("seedlings");
                    var iconCaiji = tianNode.getChildByName("icon_caiji");
                    var spriteBtqp = tianNode.getChildByName("sprite_btqp");
                    var tianB = tianNode.getChildByName("b");
                    cc.loader.loadRes("tian/" + (j + 1) + "-" + (k + 1) + "a", cc.SpriteFrame, function (err, spriteFrame) {
                        tianNode.getComponent(cc.Sprite).spriteFrame = spriteFrame;
                        cc.loader.loadRes("tian/" + (j + 1) + "-" + (k + 1) + "b", cc.SpriteFrame, function (err, spriteFrame) {
                            tianB.getComponent(cc.Sprite).spriteFrame = spriteFrame;
                            tianNode.active = true;
                        });
                    });
                    var _arr = res.list[that.columns * j + k];
                    if (_arr.isPlant == -1) {
                        //未开启
                        tianB.active = true;
                        if (_arr.landId < 9) {} else if (',9,10'.indexOf(_arr.landId) > -1) {
                            tianNode.getChildByName("label").active = true;
                        } else {
                            tianNode.getChildByName("icon_lipai").active = true;
                        }
                    } else {
                        //开启
                        tianB.active = false;
                        if (_arr.isPlant == 1) {
                            //已种植
                            cc.loader.loadRes("crops/" + _arr.giftSn + "_" + _arr.growth, cc.SpriteFrame, function (err, spriteFrame) {
                                seedlings.getComponent(cc.Sprite).spriteFrame = spriteFrame;
                                seedlings.active = true;
                                if (_arr.growth == 0) {
                                    seedlings.setPosition(cc.v2(0, 40));
                                } else {
                                    seedlings.setPosition(cc.v2(-6, 70));
                                    iconCaiji.active = _arr.recv == 1 ? true : false;
                                }
                                tianNode.getChildByName("bg_zz").active = true;
                                spriteBtqp.active = _arr.care == 0 ? true : false;
                                if (_arr.recv == 1 && _arr.care == 0 && _arr.growth == 1) {
                                    iconCaiji.setPosition(cc.v2(50, 123));
                                    spriteBtqp.setPosition(cc.v2(-50, 148));
                                }
                            });
                        }
                    }
                    that.node.getChildByName("tian").addChild(tianNode);
                    iconCaiji.on("touchend", that.tianCaiji, { evt: that, landId: _arr.landId });
                    spriteBtqp.on("touchend", that.tianCare, { evt: that, landId: _arr.landId });
                    tianNode.setPosition(that.tPosList[j][k]);
                    tianNode.pieceIdx = j * that.rows + k;
                    showTianInfo = res.list;
                };

                for (var k = 0; k < that.columns; k++) {
                    _loop2(k);
                }
            };

            for (var j = 0; j < that.rows; j++) {
                _loop(j);
            }
            cc.log(showTianInfo, that.node.getChildByName("tian"));
        });
    },
    tianCaiji: function tianCaiji() {
        var that = this;
        if (!mouseStatus) return;
        var tian = that.evt.node.getChildByName("tian");
        var tianNode = tian.children[that.landId - 1];
        var bgZz = tianNode.getChildByName("bg_zz");
        var seedlings = tianNode.getChildByName("seedlings");
        var iconCaiji = tianNode.getChildByName("icon_caiji");
        var spriteBtqp = tianNode.getChildByName("sprite_btqp");
        bgZz.active = false;
        seedlings.active = false;
        iconCaiji.active = false;
        spriteBtqp.active = false;
        cc.log('tianCaiji landId:' + that.landId);
    },
    tianCare: function tianCare() {
        var that = this;
        if (!mouseStatus) return;
        var tian = that.evt.node.getChildByName("tian");
        var tianNode = tian.children[that.landId - 1];
        var spriteBtqp = tianNode.getChildByName("sprite_btqp");
        spriteBtqp.active = false;
        cc.log('tianCaiji landId:' + that.landId);
    },
    onTouchStart: function onTouchStart(evt) {
        var that = this;
        that.holdClick = true;
        that.holdTimeEclipse = 0;
    },
    onTouchEnd: function onTouchEnd(evt) {
        var that = this;
        if (evt.getLocationX() > 600 && evt.getLocationY() > 1000 && that.holdTimeEclipse >= 30) {
            that.consoleNode.init();
        }
    },
    onDestroy: function onDestroy() {
        var that = this;
        cc.systemEvent.off(cc.SystemEvent.EventType.KEY_DOWN, that.onKeyDown, that);
        cc.systemEvent.off(cc.SystemEvent.EventType.KEY_UP, that.onKeyUp, that);
    },

    onKeyDown: function onKeyDown(event) {
        var that = this;
        switch (event.keyCode) {
            case cc.macro.KEY.back:
                console.log('Press back key');
                that.node.destroy();
                break;
        }
    },
    onKeyUp: function onKeyUp(event) {
        switch (event.keyCode) {
            case cc.macro.KEY.back:
                console.log('release a key');
                break;
        }
    },
    init: function init() {
        var that = this;
        if (userId <= 0) {
            that.loginTips();
            return;
        }
        appRequest.Get("service/game/init", {
            token: token,
            userId: userId
        }, function (rs) {
            var res = JSON.parse(rs);
            if ((typeof userInfo === "undefined" ? "undefined" : _typeof(userInfo)) == "object") {
                cc.find("Canvas/main/page1_cat_curr_bg/curr").getComponent(cc.Label).string = "x" + userInfo.propsNum;
            }
            if (result == 10000) {
                if (inviteId != -100000) {
                    cc.director.loadScene("inviteMatching");
                }
                cc.director.preloadScene("matching", function () {
                    cc.log("Next scene preloaded");
                });
            } else if (result == 10001) {
                //非游戏时间，删掉进来提示
                // that.notGameTime();
            } else {
                that.gameError();
            }
        });
    },
    notGameTime: function notGameTime() {
        this.showPanel.showPanel({
            content: "不在游戏时间",
            leftCallback: function leftCallback() {
                console.log("开始不了游戏，不在游戏时间1", Math.random());
            },
            rightCallback: function rightCallback() {
                console.log("开始不了游戏，不在游戏时间2", Math.random());
            }
        });
        that.showPanel.showPanel({
            content: "购买错误，请重新购买"
        });
    },
    start: function start() {},
    update: function update(dt) {
        var that = this;
        if (that.holdClick) {
            that.holdTimeEclipse++;
        }
    }
});

cc._RF.pop();
        }
        if (CC_EDITOR) {
            __define(__module.exports, __require, __module);
        }
        else {
            cc.registerModuleFunc(__filename, function () {
                __define(__module.exports, __require, __module);
            });
        }
        })();
        //# sourceMappingURL=farmMain.js.map
        