(function() {"use strict";var __module = CC_EDITOR ? module : {exports:{}};var __filename = 'preview-scripts/assets/Script/exchange.js';var __require = CC_EDITOR ? function (request) {return cc.require(request, require);} : function (request) {return cc.require(request, __filename);};function __define (exports, require, module) {"use strict";
cc._RF.push(module, '35522kRAwJHCbwCrMKEF99d', 'exchange', __filename);
// Script/exchange.js

"use strict";

var pool = require("pool");
var appRequest = require("network");
cc.Class({
    extends: cc.Component,

    properties: {
        tempExchangeBox: {
            default: null,
            type: cc.Prefab
        }
    },
    onLoad: function onLoad() {
        var that = this;

        clientEvent.init();

        pool.createPrefabPool(that.tempExchangeBox);

        that.node.getChildByName("bg").on("touchend", function (e) {
            e.stopPropagation();
        }, that);

        that.node.getChildByName("btn2").on("touchend", function (e) {
            e.stopPropagation();
            that.node.active = false;
        }, that);

        that.init();
    },
    init: function init() {
        var that = this;
        appRequest.Get("exchange", {
            token: 1,
            userId: 1
        }, function (rs) {
            var res = JSON.parse(rs);
            var list = res.list;

            var _loop = function _loop() {
                var exchangeBox = pool.getPrefab(that.tempExchangeBox.name);
                var x = i % 2 == 0 ? -1 : 1;
                var y = parseInt(i / 2);
                exchangeBox.setPosition(cc.v2(-172 * x, -356 * y - 175));
                var content = cc.find("Canvas/main/exchange/scrollview/view/content");
                content.height = 356 * (y + 1);
                content.setPosition(cc.v2(0, 590));
                content.addChild(exchangeBox);

                var gift = exchangeBox.getChildByName("gift1");
                cc.loader.loadRes("gift/" + list[i].giftId, cc.SpriteFrame, function (err, spriteFrame) {
                    gift.getComponent(cc.Sprite).spriteFrame = spriteFrame;
                    gift.active = true;
                });
                var vBg = exchangeBox.getChildByName("v-bg");
                var vip = exchangeBox.getChildByName("v");
                var title = exchangeBox.getChildByName("title");
                var exchangeBtn = exchangeBox.getChildByName("exchangeBtn");
                exchangeBtn.on("touchend", that.exchangeRes, {
                    evt: that,
                    giftId: 1312, //兑换的礼物ID
                    needSn: 1001 //需要的碎片ID
                });
                var btnName = exchangeBtn.getChildByName("Background").getChildByName("Label");
                if (list[i].needVip == 0) {
                    vBg.active = false;
                    vip.active = false;
                } else {
                    vip.getComponent(cc.Label).string = 'V' + list[i].needVip;
                }
                title.getComponent(cc.Label).string = '由' + debrisConfig[list[i].needSn].name + '组成';
                btnName.getComponent(cc.Label).string = '兑换' + list[i].needNum + '/' + list[i].hadNum;
            };

            for (var i = 0; i < list.length; i++) {
                _loop();
            }
        });
    },
    exchangeRes: function exchangeRes() {
        var evt = this;
        cc.log(evt.giftId, '兑换的礼物ID');
    },
    start: function start() {}
}

// update (dt) {},
);

cc._RF.pop();
        }
        if (CC_EDITOR) {
            __define(__module.exports, __require, __module);
        }
        else {
            cc.registerModuleFunc(__filename, function () {
                __define(__module.exports, __require, __module);
            });
        }
        })();
        //# sourceMappingURL=exchange.js.map
        