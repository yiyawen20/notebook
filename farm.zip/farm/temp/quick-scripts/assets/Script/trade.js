(function() {"use strict";var __module = CC_EDITOR ? module : {exports:{}};var __filename = 'preview-scripts/assets/Script/trade.js';var __require = CC_EDITOR ? function (request) {return cc.require(request, require);} : function (request) {return cc.require(request, __filename);};function __define (exports, require, module) {"use strict";
cc._RF.push(module, 'f74d6ADM/NJG5CnvdqgWZui', 'trade', __filename);
// Script/trade.js

"use strict";

cc.Class({
    extends: cc.Component,

    properties: {},
    onLoad: function onLoad() {
        var that = this;
        that.node.getChildByName("bg").on("touchend", function (e) {
            e.stopPropagation();
        }, that);
        that.node.getChildByName("btn2").on("touchend", function (e) {
            e.stopPropagation();
            that.node.active = false;
        }, that);

        that.shop = that.node.getChildByName("shop");
        that.storage = that.node.getChildByName("storage");
        that.sale = that.node.getChildByName("sale");
        that.record = that.node.getChildByName("record");

        that.qie1 = that.node.getChildByName("qie1");
        that.qie2 = that.node.getChildByName("qie2");
        that.qie3 = that.node.getChildByName("qie3");
        that.qie4 = that.node.getChildByName("qie4");
        that.qie1.on("touchend", that.switchTab, { evt: that, idx: 1 });
        that.qie2.on("touchend", that.switchTab, { evt: that, idx: 2 });
        that.qie3.on("touchend", that.switchTab, { evt: that, idx: 3 });
        that.qie4.on("touchend", that.switchTab, { evt: that, idx: 4 });
    },
    switchTab: function switchTab() {
        var that = this.evt;
        var idx = this.idx;
        that.qie1.getChildByName("qie1").active = false;
        that.qie2.getChildByName("qie1").active = false;
        that.qie3.getChildByName("qie1").active = false;
        that.qie4.getChildByName("qie1").active = false;
        that.shop.active = false;
        that.storage.active = false;
        that.sale.active = false;
        that.record.active = false;
        if (idx == 1) {
            that.qie1.getChildByName("qie1").active = true;
            that.shop.active = true;
        } else if (idx == 2) {
            that.qie2.getChildByName("qie1").active = true;
            that.storage.active = true;
        } else if (idx == 3) {
            that.qie3.getChildByName("qie1").active = true;
            that.sale.active = true;
        } else if (idx == 4) {
            that.qie4.getChildByName("qie1").active = true;
            that.record.active = true;
        }
    },
    start: function start() {}
}

// update (dt) {},
);

cc._RF.pop();
        }
        if (CC_EDITOR) {
            __define(__module.exports, __require, __module);
        }
        else {
            cc.registerModuleFunc(__filename, function () {
                __define(__module.exports, __require, __module);
            });
        }
        })();
        //# sourceMappingURL=trade.js.map
        