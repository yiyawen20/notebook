(function() {"use strict";var __module = CC_EDITOR ? module : {exports:{}};var __filename = 'preview-scripts/assets/Script/basic/wxLogin.js';var __require = CC_EDITOR ? function (request) {return cc.require(request, require);} : function (request) {return cc.require(request, __filename);};function __define (exports, require, module) {"use strict";
cc._RF.push(module, '3fa5bu8XRxPaLYmFPud1MXK', 'wxLogin', __filename);
// Script/basic/wxLogin.js

"use strict";

// wxlogin yyw

var redis = require('redis');
var appRequest = require("network");

function wxAutoLogin(cb) {
    var that = this;
    var key = redis.get("logout");
    if (key == 1) {
        //表示当前为退出状态，不能自动登录
        if (typeof cb == "function") {
            cb();
        }
        return;
    }

    var sysInfo = window.wx.getSystemInfoSync();
    //获取微信界面大小
    var width = sysInfo.screenWidth;
    var height = sysInfo.screenHeight;

    console.log("微信登录");
    var button = wx.createUserInfoButton({
        type: 'text',
        text: '获取用户信息',
        style: {
            left: 0,
            top: 0,
            width: width,
            height: height,
            lineHeight: height,
            backgroundColor: '#00000050',
            color: '#ffffff',
            textAlign: 'center',
            fontSize: 16,
            borderRadius: 0
        }
    });
    button.onTap(function (res) {
        if (res.userInfo) {
            console.log("登录信息" + res);
            //此时可进行登录操作
            wx.login({
                success: function success(rs) {
                    redis.put("author", "yyw", 3600 * 24 * 365);
                    window.code = rs.code;
                    var encryptedData = res.encryptedData;
                    var iv = res.iv;
                    var nickName = res.userInfo.nickName;
                    var avatar = res.userInfo.avatarUrl;
                    var path = "imimini/login/byWx";
                    var data = {
                        appId: "wx14e14e780984fa4e",
                        encryptedData: encryptedData,
                        iv: iv,
                        code: code,
                        nickName: nickName,
                        avatarUrl: avatar,
                        shareId: shareId

                    };
                    var _url = config.baseReqUrl;
                    config.baseReqUrl = loginReqUrl[config.env];
                    appRequest.Get(path, data, function (resp) {
                        config.baseReqUrl = _url;
                        var key = redis.get("logout");
                        if (key == 1) {
                            redis.remove("logout");
                        }
                        userId = resp.userId;
                        token = resp.token;
                        userInfo.nickName = resp.nickName;
                        userInfo.avatarUrl = resp.avatar;
                        var _arr = {
                            userId: userId,
                            token: token,
                            userInfo: userInfo
                        };
                        redis.put("wxLoginData", JSON.stringify(_arr), 3600 * 24 * 365); //秒
                        if (typeof cb == "function") {
                            cb();
                        }
                        button.hide();
                    });
                }
            });
        } else {
            console.log("用户拒绝授权:", res);
        }
    });

    /*wx.getSetting({
      success (res) {
          console.log(res.authSetting);
          if (res.authSetting["scope.userInfo"]) {
              console.log("用户已授权");
              wx.getUserInfo({
                  success(res){
                      console.log(res);
                      //此时可进行登录操作
                  }
              });
              if ((typeof cb) == "function") {
                  cb();
              }
          }else {
            console.log("用户未授权用户未授权用户未授权用户未授权");
              //用户未授权
          }
      }
    })*/
}

function wxLogin(routeUrl) {
    if (userId <= 0) {
        //微信登录
    }
}

//绑定手机
function wxBindPhone(routeUrl) {}
//绑定手机


//退出
function submitLogout() {
    var that = this;
    try {
        var key = redis.get("logout");
        if (!key) {
            redis.put("logout", 1, 3600 * 24 * 365); //秒
        }
        redis.remove("phoneLoginData");
        redis.remove("wxLoginData");
    } catch (e) {}
    userId = -parseInt(Math.random() * 1e6);
    token = undefined;
    userInfo = {};
}

module.exports = {
    wxAutoLogin: wxAutoLogin,
    wxLogin: wxLogin,
    wxBindPhone: wxBindPhone,
    submitLogout: submitLogout
};

cc._RF.pop();
        }
        if (CC_EDITOR) {
            __define(__module.exports, __require, __module);
        }
        else {
            cc.registerModuleFunc(__filename, function () {
                __define(__module.exports, __require, __module);
            });
        }
        })();
        //# sourceMappingURL=wxLogin.js.map
        