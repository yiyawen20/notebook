(function() {"use strict";var __module = CC_EDITOR ? module : {exports:{}};var __filename = 'preview-scripts/assets/Script/basic/global.js';var __require = CC_EDITOR ? function (request) {return cc.require(request, require);} : function (request) {return cc.require(request, __filename);};function __define (exports, require, module) {"use strict";
cc._RF.push(module, 'fe634XAsUZE+YQyVWbrVgRw', 'global', __filename);
// Script/basic/global.js

"use strict";

//窗口
window.win = {
    width: 750,
    height: 1334
};

window.mouseStatus = true;

window.webSocketState = 0; //webSocket是否连接，0表示没连接
window.kickoutState = 0; //断开状态，1表示断开，2表示系统异常断开

window.commonCode = {}; //没有解析的消息


window.query2Obj = function () {
    var result = {};
    var query = location.search.slice(1);
    var arr = query.split("&");
    for (var i = 0; i < arr.length; i++) {
        var brr = arr[i].split('=');
        result[brr[0]] = brr[1];
    }
    return result;
};
window.userId = -parseInt(Math.random() * 1e6);
window.token = undefined;
window.userInfo = {};

window.showTianInfo = [];

window.consoleArr = [];
var log = cc.log;
cc.log = function () {
    // log("cc:"+text);
    var text = "";
    for (var i in arguments) {
        text += arguments[i];
    }
    if (config.env != "product") {
        log.call(cc, "cc:" + text); //使用call让log里面的this指向console,而不是window
    }
    if (consoleArr.length > 120) {
        consoleArr.splice(0, 1);
    }
    consoleArr.push("cc:" + text);
};

var log = console.log;
console.log = function () {
    // log("console:"+text);
    var text = "";
    for (var i in arguments) {
        text += arguments[i];
    }
    if (config.env != "product") {
        log.call(console, "console:" + text); //使用call让log里面的this指向console,而不是window
    }
    if (consoleArr.length > 120) {
        consoleArr.splice(0, 1);
    }
    consoleArr.push("console:" + text);
};

cc._RF.pop();
        }
        if (CC_EDITOR) {
            __define(__module.exports, __require, __module);
        }
        else {
            cc.registerModuleFunc(__filename, function () {
                __define(__module.exports, __require, __module);
            });
        }
        })();
        //# sourceMappingURL=global.js.map
        