(function() {"use strict";var __module = CC_EDITOR ? module : {exports:{}};var __filename = 'preview-scripts/assets/Script/scrollLabel.js';var __require = CC_EDITOR ? function (request) {return cc.require(request, require);} : function (request) {return cc.require(request, __filename);};function __define (exports, require, module) {"use strict";
cc._RF.push(module, 'b79f5djRKtBC4RhayeHup+j', 'scrollLabel', __filename);
// Script/scrollLabel.js

'use strict';

cc.Class({
    extends: cc.Component,

    properties: {
        // foo: {
        //     // ATTRIBUTES:
        //     default: null,        // The default value will be used only when the component attaching
        //                           // to a node for the first time
        //     type: cc.SpriteFrame, // optional, default is typeof default
        //     serializable: true,   // optional, default is true
        // },
        // bar: {
        //     get () {
        //         return this._bar;
        //     },
        //     set (value) {
        //         this._bar = value;
        //     }
        // },
        itemLabel: {
            default: null,
            type: cc.Label
        }
    },
    onLoad: function onLoad() {
        var that = this;

        // 初始化跳跃动作
        // that.scrollAction = that.setScrollAction();
        // that.node.runAction(that.scrollAction);

        that.itemNumber = 4;
        that.itemLabel.node.active = true;
        that.itemLabel.string = '12-03 22：33 比一句中访问了你的农场，并照料了你的满天星幼苗~~\n' + '12-03 22：33 暗室逢灯发送给发货1~~\n' + '12-03 22：33 同仁堂和教育局统一发放的方式发给红包呢2~~\n' + '12-03 22：33 啊实打实大扫荡法规实打实阿打算 阿打算多 阿达3~~\n';

        that.setScrollAction();
    },

    setScrollAction: function setScrollAction() {
        var that = this;
        that.idx = 0;
        // 以秒为单位的时间间隔
        var interval = 5;
        that.callback = function () {
            that.idx++;
            that.scrollAction();
        };
        that.schedule(that.callback, interval);
    },
    scrollAction: function scrollAction() {
        var that = this;
        if (that.idx >= that.itemNumber) {
            that.idx = 0;
            that.itemLabel.node.setPosition(cc.v2(0, 25));
        } else {
            var callback = cc.callFunc(that.completeLabel, that, [that.idx]);
            var seq = cc.sequence(cc.moveBy(0, cc.v2(0, 0)), cc.moveBy(0.5, cc.v2(0, 40)), callback);
            that.itemLabel.node.runAction(seq);
        }
    },
    completeLabel: function completeLabel(evt, arr) {
        // cc.log('completeLabel:', arr[0]);
    },
    start: function start() {}
}

// update (dt) {},
);

cc._RF.pop();
        }
        if (CC_EDITOR) {
            __define(__module.exports, __require, __module);
        }
        else {
            cc.registerModuleFunc(__filename, function () {
                __define(__module.exports, __require, __module);
            });
        }
        })();
        //# sourceMappingURL=scrollLabel.js.map
        