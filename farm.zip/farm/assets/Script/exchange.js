cc.Class({
    extends: cc.Component,

    properties: {
    },
    onLoad () {
        let that = this;
        that.node.getChildByName("btn2").on("touchend", function(){
            mouseStatus = true;
            that.node.active = false;
        }, that);
    },

    start () {},

    // update (dt) {},
});
